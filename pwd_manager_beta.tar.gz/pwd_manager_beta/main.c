#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define warn(...) printf("[WARNING] " __VA_ARGS__);
#define info(...) printf("[INFO] " __VA_ARGS__);
#define STRING_SIZE 900
#define COMMANDS_SIZE 900
#define KEY_SIZE 400
#define DEBUG_MODE 0

void print_menu(void){
	printf("\n|pwm| ");
}

void print_commands_list(void){
	printf("\nCommands list:\n\
\tlist - to print list of passwords\n\
\tcreate - to create a password\n\
\thelp - to print this menu\n\
\tquit - to exit the program\n");
}

char *encrypt(const char *str, const char *key_str, int str_size, int key_str_size){
	char *result = (char *)malloc((sizeof(char) * (str_size + 1))); 
	
	size_t i;
	for(i = 0; i < str_size; i++){
		if((str[i] ^ key_str[i % key_str_size]) != 0)	
			result[i] = str[i] ^ key_str[i % key_str_size];
		else
			result[i] = str[i] ^ key_str[i % key_str_size] + 1;

	}
	
	result[i] = '\0';

	return result;
}

char *decrypt(const char *str, const char *key_str, int str_size, int key_str_size){
	char *result = (char *)malloc(sizeof(char) * (str_size + 1)); 

	size_t i;
	for( i = 0; i < str_size; i++){	
		if((str[i] ^ key_str[i % key_str_size]) != 0)
			result[i] = str[i] ^ key_str[i % key_str_size];
		else	
			result[i] = (str[i] - 1) ^ key_str[i % key_str_size];
	}
	
	result[i] = '\0';

	return result;
}

unsigned long get_file_size(FILE *filestream){
	unsigned long fsize = 0;
	fseek(filestream, 0, SEEK_END);
	fsize = ftell(filestream);

	return fsize;	
}

//argv[1] -> passwords file
//argv[2] -> key
int main(int argc, const char const * argv[]){
	srand(time(NULL));
	FILE *saves = NULL; 
	char current_string[STRING_SIZE];
	char commands[COMMANDS_SIZE];
	char key[KEY_SIZE];
	long fp_pos = 0;
	bool is_saves_empty = false;
	
	if(argc < 3){
		warn("USAGE: password_manager passwords.txt key\n");
		return EXIT_FAILURE;
	}

	saves = fopen(argv[1], "rb+");
	strcpy(key, argv[2]);
	info("Saves file: %s, Key value: %s\n", argv[1], argv[2]);	

	if(!saves){
		warn("Couldn't open saves file!\n");
		return EXIT_FAILURE;
	}

	info("Opened saves.txt\n");
	
	if(!fgets(current_string, STRING_SIZE, saves)){
		info("Saves file is empty!\n");
		is_saves_empty = true;
	}

	fp_pos = get_file_size(saves);

	bool is_running = true;
	while(is_running){
		print_menu();
		
		char command[20];
		//     www.site.com password
		char args[2][400];
		memset(args[0], 0, sizeof(args[0]));
		memset(args[1], 0, sizeof(args[1]));

		fgets(commands, COMMANDS_SIZE, stdin);
		
		sscanf(commands, "%s %s %s", command, args[0], args[1]);
		
		if(!strcmp(command, "create")){
			fseek(saves, fp_pos, SEEK_SET);

			int temp_length = strlen(args[0]) + strlen(args[1]) + 3;
			char *temp = (char *)malloc(temp_length *
						sizeof(char)); // +  ' ' + '\n' + '\0'
			
			memset(temp, 0, temp_length * sizeof(char));

			sprintf(temp, "%s %s\n", args[0], args[1]);

			char *temp1 = encrypt(temp, key, strlen(temp), strlen(key));

			fwrite(temp1, (temp_length - 1) * sizeof(char), 1, saves);
			
			fp_pos = ftell(saves);

			free(temp);
			free(temp1);

			is_saves_empty = false;
		}
		else if(!strcmp(command, "list")){
			if(is_saves_empty){
				info("Saves file is empty!\n");
			}
			else {
				char site[200] = {0};
				char pass[200] = {0};
				char *data = NULL;
				char *enc_data = NULL;

				rewind(saves);
				memset(current_string, 0, sizeof(current_string));
			
				data = (char *)malloc(fp_pos + 1);
				memset(data, 0, fp_pos + 1);

				fread(data, fp_pos, 1, saves);

				enc_data = encrypt(data, key, strlen(data), strlen(key));

				//printf("Encrypted data: \n\t%s\nData length: %ld\nFp_pos: %ld\n%d", enc_data, strlen(data), fp_pos, data[29]);
				
				char *temp_enc_data = enc_data;
				while(sscanf(temp_enc_data, "%s %s", site, pass) == 2){
					printf("Site -> %s\tPass -> %s\n", site, pass);
					
					temp_enc_data += strlen(site) + strlen(pass) + 1;
				}

				free(data);
				free(enc_data);
			}
		}
		else if(!strcmp(command, "remove")){
			if(!remove(args[0])){
				info("File %s remove successfully!\n", args[0]);
			}
			else warn("Couldn't remove %s\n", args[0]);
		}
		else if(!strcmp(command, "clear")){
			
		}
		else if(!strcmp(command, "help")){
			print_commands_list();
		}
		else if(!strcmp(command, "quit")){
			is_running = false;
		}
		else {
			warn("%s is undefined", command);
			print_commands_list();
		}
	}
	
	fclose(saves);
	return EXIT_SUCCESS;
}

